export const movies = [
    {
        id: "1",
        movieName: "Weather With You",
        description: "Mùa hè năm đầu cấp Ba, Hodaka bỏ nhà ra đi...",
        image: "images/image1.jpg",
        episode: "01"
    },
    {
        id: "2",
        movieName: "Once Peace",
        description: "One Piece là bộ truyện tranh dành cho thiếu niên của tác giả nổi tiếng Oda Eiichiro...",
        image: "images/image2.jpg",
        episode: "1018"
    },
    {
        id: "3",
        movieName: "Boruto: Naruto Next Generations",
        description: "Boruto: Naruto Next Generations kể về thế hệ sau của Naruto...",
        image: "images/image3.jpg",
        episode: "250"
    },
    {
        id: "4",
        movieName: "Spy X Family",
        description: "Bộ phim là phần phim điện ảnh của series anime nổi tiếng Spy x Family...",
        image: "images/image4.jpg",
        episode: "07"
    },
    {
        id: "5",
        movieName: "Shingeki no kyojin",
        description: "Câu chuyện của Đại chiến Titan tập trung vào một nền văn minh...",
        image: "images/image5.jpg",
        episode: "28"
    },
    {
        id: "6",
        movieName: "Captain Tsubasa",
        description: "Tsubasa Oozora là nhân vật chính trong bộ truyện này...",
        image: "images/image6.jpg",
        episode: "28"
    },
    {
        id: "7",
        movieName: "Ao Ashi",
        description: "Ashito Aoi là một cầu thủ bóng đá trẻ, đầy khát vọng...",
        image: "images/image7.jpg",
        episode: "28"
    }
];