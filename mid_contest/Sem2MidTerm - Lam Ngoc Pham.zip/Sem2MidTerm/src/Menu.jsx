import React from "react";
import './menu.css';

const Menu = () => {
    return (
        <div className="menu">
            <h1>Explore</h1>
        </div>
    )
}

export default Menu